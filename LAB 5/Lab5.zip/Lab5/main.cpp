#include <windows.h>
#include <GL/glut.h>
#include <math.h>

void display() {

    glClear(GL_COLOR_BUFFER_BIT);

    // Bloque izquierdo alto
    glColor3f(0.2f, 0.2f, 0.2f);
    glBegin(GL_QUADS);
        glVertex2f(-0.7f, -0.6f);
        glVertex2f(-0.7f, 0.8f);
        glVertex2f(-0.45f, 0.8f);
        glVertex2f(-0.45f, -0.6f);
    glEnd();

    // Bloque medio
    glColor3f(0.3f, 0.3f, 0.3f);
    glBegin(GL_QUADS);
        glVertex2f(-0.45f, -0.6f);
        glVertex2f(-0.45f, 0.4f);
        glVertex2f(0.2f, 0.4f);
        glVertex2f(0.2f, -0.6f);
    glEnd();

    // Bloque derecho bajo
    glColor3f(0.4f, 0.4f, 0.4f);
    glBegin(GL_QUADS);
        glVertex2f(0.2f, -0.6f);
        glVertex2f(0.2f, 0.1f);
        glVertex2f(0.65f, 0.1f);
        glVertex2f(0.65f, -0.6f);
    glEnd();

    // Techo
    glColor3f(0.1f, 0.1f, 0.1f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.7f, 0.8f);
        glVertex2f(-0.45f, 0.8f);
        glVertex2f(-0.45f, 0.4f);
        glVertex2f(0.2f, 0.4f);
        glVertex2f(0.2f, 0.1f);
        glVertex2f(0.65f, 0.1f);
        glVertex2f(0.65f, 0.05f);
        glVertex2f(-0.7f, 0.05f);
    glEnd();

    // Ventanas
    glColor3f(0.8f, 0.9f, 1.0f);

    float y = 0.7f;

    for (int i = 0; i < 3; i++) {
        glBegin(GL_QUADS);
            glVertex2f(-0.65f, y - 0.25f);
            glVertex2f(-0.5f, y - 0.25f);
            glVertex2f(-0.5f, y + 0.05f);
            glVertex2f(-0.65f, y + 0.05f);
        glEnd();

        y -= 0.50f;
    }

    // Ventana derecha
    glBegin(GL_QUADS);
        glVertex2f(0.3f, -0.40f);
        glVertex2f(0.55f, -0.40f);
        glVertex2f(0.55f, -0.15f);
        glVertex2f(0.3f, -0.15f);
    glEnd();

    // Puerta
    glColor3f(0.85f, 0.85f, 0.85f);

    glBegin(GL_QUADS);
        glVertex2f(-0.35f, -0.6f);
        glVertex2f(-0.15f, -0.6f);
        glVertex2f(-0.15f, -0.35f);
        glVertex2f(-0.35f, -0.35f);
    glEnd();

    // Marco puerta
    glColor3f(0.94f, 0.90f, 0.55f);

    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.35f, -0.6f);
        glVertex2f(-0.15f, -0.6f);
        glVertex2f(-0.15f, -0.35f);
        glVertex2f(-0.35f, -0.35f);
    glEnd();

    glFlush();
}

void init() {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluOrtho2D(-1, 1, -1, 1);
}

int main(int argc, char** argv) {

    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);

    glutInitWindowSize(900, 700);

    glutCreateWindow("Casa Gris");

    init();

    glutDisplayFunc(display);

    glutMainLoop();

    return 0;
}

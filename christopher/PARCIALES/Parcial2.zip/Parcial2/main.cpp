#include <windows.h>
#include <GL/glut.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

void init()
{
    glClearColor(0.0, 0.0, 0.0, 1); // Fondo completamente negro
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, 1000, 0, 700);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    // ==========================================
    // 1. FONDO (10 puntos) - Cielo y Suelo
    // ==========================================

    // Cielo Nocturno (GL_QUADS)
    glColor3f(0.0, 0.0, 0.0);
    glBegin(GL_QUADS);
        glVertex2f(0, 300);    glVertex2f(1000, 300);
        glVertex2f(1000, 700); glVertex2f(0, 700);
    glEnd();

    // Estrellas (GL_POINTS)
    glColor3f(1.0, 1.0, 1.0);
    glPointSize(2.0);
    glBegin(GL_POINTS);
        glVertex2f(150, 600); glVertex2f(250, 450); glVertex2f(350, 650);
        glVertex2f(450, 550); glVertex2f(550, 680); glVertex2f(650, 500);
        glVertex2f(750, 620); glVertex2f(100, 500); glVertex2f(900, 660);
        glVertex2f(800, 480); glVertex2f(50, 530);  glVertex2f(300, 520);
    glEnd();

    // Mar/Agua (GL_QUADS)
    glColor3f(0.031, 0.506, 0.949);
    glBegin(GL_QUADS);
        glVertex2f(0, 0);      glVertex2f(1000, 0);
        glVertex2f(1000, 120); glVertex2f(0, 120);
    glEnd();

    // Suelo de c�sped (GL_QUADS) - Degradado
    glBegin(GL_QUADS);
        // Izquierda (#00ee00)
        glColor3f(0.0, 0.933, 0.0);
        glVertex2f(0, 220);
        // Derecha (#008000)
        glColor3f(0.0, 0.502, 0.0);
        glVertex2f(1000, 220);
        glVertex2f(1000, 300);
        // Izquierda (#00ee00)
        glColor3f(0.0, 0.933, 0.0);
        glVertex2f(0, 300);
    glEnd();

    // ==========================================
    // 2. MONTA�AS Y LUNA (10 puntos)
    // ==========================================

    // Monta�a 1 - Izquierda
    glColor3f(0.4, 0.0, 0.0);
    glBegin(GL_TRIANGLES);
        glVertex2f(0, 300); glVertex2f(350, 300); glVertex2f(175, 600);
    glEnd();
    // Pico 1 (EL M�S GRANDE)
    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_TRIANGLES);
        glVertex2f(93, 460); glVertex2f(257, 460); glVertex2f(175, 600);
    glEnd();

    // Monta�a 2 - Centro
    glColor3f(0.4, 0.0, 0.0);
    glBegin(GL_TRIANGLES);
        glVertex2f(200, 300); glVertex2f(600, 300); glVertex2f(400, 520);
    glEnd();
    // Pico 2 (M�S PEQUE�O QUE EL 1)
    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_TRIANGLES);
        glVertex2f(309, 420); glVertex2f(491, 420); glVertex2f(400, 520);
    glEnd();

    // Monta�a 3 - Derecha
    glColor3f(0.2, 0.0, 0.0);
    glBegin(GL_TRIANGLES);
        glVertex2f(500, 300); glVertex2f(950, 300); glVertex2f(725, 580);
    glEnd();
    // Pico 3 (UN POCO M�S PEQUE�O QUE EL 2)
    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_TRIANGLES);
        glVertex2f(661, 500); glVertex2f(789, 500); glVertex2f(725, 580);
    glEnd();

    // Luna (GL_POLYGON)
    glColor3f(0.976, 1.0, 0.408);
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i += 10) {
        float theta = i * M_PI / 180.0f;
        glVertex2f(850 + 50 * cos(theta), 550 + 50 * sin(theta));
    }
    glEnd();

    // ==========================================
    // 4. EDIFICIOS Y COLUMPIO (10 puntos)
    // ==========================================

    // EDIFICIO NARANJA
    glColor3f(1.0, 0.502, 0.0);
    glBegin(GL_QUADS);
        glVertex2f(80, 220);  glVertex2f(270, 220);
        glVertex2f(270, 480); glVertex2f(80, 480);
    glEnd();

    // Ventanas Edificio Naranja
    glColor3f(1.0, 1.0, 0.0);
    glBegin(GL_QUADS);
        glVertex2f(100, 250); glVertex2f(135, 250); glVertex2f(135, 290); glVertex2f(100, 290);
        glVertex2f(155, 250); glVertex2f(190, 250); glVertex2f(190, 290); glVertex2f(155, 290);
        glVertex2f(210, 250); glVertex2f(245, 250); glVertex2f(245, 290); glVertex2f(210, 290);
        glVertex2f(100, 320); glVertex2f(135, 320); glVertex2f(135, 360); glVertex2f(100, 360);
        glVertex2f(155, 320); glVertex2f(190, 320); glVertex2f(190, 360); glVertex2f(155, 360);
        glVertex2f(210, 320); glVertex2f(245, 320); glVertex2f(245, 360); glVertex2f(210, 360);
        glVertex2f(100, 390); glVertex2f(135, 390); glVertex2f(135, 430); glVertex2f(100, 430);
        glVertex2f(155, 390); glVertex2f(190, 390); glVertex2f(190, 430); glVertex2f(155, 430);
        glVertex2f(210, 390); glVertex2f(245, 390); glVertex2f(245, 430); glVertex2f(210, 430);
    glEnd();

    // EDIFICIO AZUL CON DEGRADADO
    glBegin(GL_QUADS);
        glColor3f(0.0, 0.494, 1.0);
        glVertex2f(550, 220);
        glVertex2f(550, 420);
        glColor3f(0.0, 0.173, 1.0);
        glVertex2f(650, 420);
        glVertex2f(650, 220);
    glEnd();

    // Ventanas Edificio Azul
    glColor3f(1.0, 1.0, 0.0);
    glBegin(GL_QUADS);
        glVertex2f(565, 250); glVertex2f(590, 250); glVertex2f(590, 280); glVertex2f(565, 280);
        glVertex2f(610, 250); glVertex2f(635, 250); glVertex2f(635, 280); glVertex2f(610, 280);
        glVertex2f(565, 310); glVertex2f(590, 310); glVertex2f(590, 340); glVertex2f(565, 340);
        glVertex2f(610, 310); glVertex2f(635, 310); glVertex2f(635, 340); glVertex2f(610, 340);
        glVertex2f(565, 370); glVertex2f(590, 370); glVertex2f(590, 400); glVertex2f(565, 400);
        glVertex2f(610, 370); glVertex2f(635, 370); glVertex2f(635, 400); glVertex2f(610, 400);
    glEnd();

    // COLUMPIO
    glColor3f(0.224, 0.192, 0.145);
    glLineWidth(4.0);
    glBegin(GL_LINES);
        glVertex2f(700, 220); glVertex2f(740, 350);
        glVertex2f(780, 220); glVertex2f(740, 350);
        glVertex2f(840, 220); glVertex2f(880, 350);
        glVertex2f(920, 220); glVertex2f(880, 350);
        glVertex2f(740, 350); glVertex2f(880, 350);

        glColor3f(0.3, 0.3, 0.3);
        glVertex2f(780, 350); glVertex2f(780, 270);
        glVertex2f(840, 350); glVertex2f(840, 270);
    glEnd();
    glLineWidth(1.0);

    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_QUADS);
        glVertex2f(770, 260); glVertex2f(850, 260);
        glVertex2f(850, 270); glVertex2f(770, 270);
    glEnd();

    glColor3f(0.0, 0.0, 0.0);
    glLineWidth(2.0);
    glBegin(GL_LINE_LOOP);
        glVertex2f(770, 260); glVertex2f(850, 260);
        glVertex2f(850, 270); glVertex2f(770, 270);
    glEnd();
    glLineWidth(1.0);

    // ==========================================
    // 3. �RBOLES (10 puntos)
    // ==========================================

    int treeX[3] = {330, 430, 680};
    for (int i = 0; i < 3; i++) {
        // Tronco
        glColor3f(0.6, 0.4, 0.122);
        glBegin(GL_QUADS);
            glVertex2f(treeX[i] - 15, 220); glVertex2f(treeX[i] + 15, 220);
            glVertex2f(treeX[i] + 15, 260); glVertex2f(treeX[i] - 15, 260);
        glEnd();

        // Hojas
        glColor3f(0.0, 0.502, 0.0);
        glBegin(GL_TRIANGLES);

        if (i == 0) {
            // PRIMER �RBOL: 2 tri�ngulos EXACTAMENTE IGUALES, NO superpuestos
            // Tri�ngulo 1
            glVertex2f(treeX[i] - 40, 260); glVertex2f(treeX[i] + 40, 260); glVertex2f(treeX[i], 310);
            // Tri�ngulo 2
            glVertex2f(treeX[i] - 40, 310); glVertex2f(treeX[i] + 40, 310); glVertex2f(treeX[i], 360);
        } else {
            // SEGUNDO Y TERCER �RBOL: 3 tri�ngulos EXACTAMENTE IGUALES, NO superpuestos
            // Tri�ngulo 1
            glVertex2f(treeX[i] - 40, 260); glVertex2f(treeX[i] + 40, 260); glVertex2f(treeX[i], 310);
            // Tri�ngulo 2
            glVertex2f(treeX[i] - 40, 310); glVertex2f(treeX[i] + 40, 310); glVertex2f(treeX[i], 360);
            // Tri�ngulo 3
            glVertex2f(treeX[i] - 40, 360); glVertex2f(treeX[i] + 40, 360); glVertex2f(treeX[i], 410);
        }

        glEnd();
    }

    // ==========================================
    // 5. ELEMENTOS LINEALES (10 puntos) - Carretera Gris (#777777)
    // ==========================================

    // CARRETERA
    glColor3f(0.467, 0.467, 0.467); // Gris (#777777)
    glBegin(GL_QUADS);
        glVertex2f(0, 120);    glVertex2f(1000, 120);
        glVertex2f(1000, 220); glVertex2f(0, 220);
    glEnd();

    glColor3f(1.0, 1.0, 1.0);
    glLineWidth(4.0);
    glBegin(GL_LINES);
    for (int x = 20; x < 1000; x += 80) {
        glVertex2f(x, 170); glVertex2f(x + 40, 170);
    }
    glEnd();
    glLineWidth(1.0);

    // BARCO
    glColor3f(0.0, 0.0, 0.0);
    glBegin(GL_QUADS);
        glVertex2f(500, 30);
        glVertex2f(700, 30);
        glVertex2f(740, 70);
        glVertex2f(460, 70);
    glEnd();

    glColor3f(0.0, 0.0, 0.0);
    glBegin(GL_LINE_LOOP);
        glVertex2f(500, 30); glVertex2f(700, 30); glVertex2f(740, 70); glVertex2f(460, 70);
    glEnd();

    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_QUADS);
        glVertex2f(530, 70);  glVertex2f(670, 70);
        glVertex2f(670, 130); glVertex2f(530, 130);
    glEnd();

    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(1000, 700);
    glutCreateWindow("Parcial OpenGL");

    init();

    glutDisplayFunc(display);

    glutMainLoop();
    return 0;
}

#include <windows.h>
#include <GL/glut.h>

// Funci�n para dibujar texto
void texto(float x, float y, const char* str)
{
    glRasterPos2f(x, y);

    while (*str)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *str);
        str++;
    }
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    // ===== GROSOR DE L�NEAS =====
    glLineWidth(4.0);

    // =====================================================
    //                  CABEZA
    // =====================================================

    // Relleno cabeza
    glColor3f(0.9, 0.9, 0.9);

    glBegin(GL_POLYGON);
        glVertex2f(-0.15, 0.55);
        glVertex2f(0.15, 0.55);
        glVertex2f(0.15, 0.85);
        glVertex2f(-0.15, 0.85);
    glEnd();

    // Borde cabeza
    glColor3f(0.0, 0.0, 0.0);

    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.15, 0.55);
        glVertex2f(0.15, 0.55);
        glVertex2f(0.15, 0.85);
        glVertex2f(-0.15, 0.85);
    glEnd();

    // =====================================================
    //                  CUERPO / SU�TER ROJO
    // =====================================================

    glColor3f(0.8, 0.0, 0.0); // Rojo

    glBegin(GL_POLYGON);
        glVertex2f(-0.15, 0.10);
        glVertex2f(0.15, 0.10);
        glVertex2f(0.15, 0.55);
        glVertex2f(-0.15, 0.55);
    glEnd();

    // Bordes cuerpo
    glColor3f(0.0, 0.0, 0.0);

    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.15, 0.10);
        glVertex2f(0.15, 0.10);
        glVertex2f(0.15, 0.55);
        glVertex2f(-0.15, 0.55);
    glEnd();

    // =====================================================
    //                  BRAZO IZQUIERDO
    // =====================================================

    glColor3f(0.8, 0.0, 0.0);

    glBegin(GL_POLYGON);
        glVertex2f(-0.30, 0.20);
        glVertex2f(-0.15, 0.20);
        glVertex2f(-0.15, 0.50);
        glVertex2f(-0.30, 0.50);
    glEnd();

    glColor3f(0.0, 0.0, 0.0);

    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.30, 0.20);
        glVertex2f(-0.15, 0.20);
        glVertex2f(-0.15, 0.50);
        glVertex2f(-0.30, 0.50);
    glEnd();

    // =====================================================
    //                  BRAZO DERECHO
    // =====================================================

    glColor3f(0.8, 0.0, 0.0);

    glBegin(GL_POLYGON);
        glVertex2f(0.15, 0.20);
        glVertex2f(0.30, 0.20);
        glVertex2f(0.30, 0.50);
        glVertex2f(0.15, 0.50);
    glEnd();

    glColor3f(0.0, 0.0, 0.0);

    glBegin(GL_LINE_LOOP);
        glVertex2f(0.15, 0.20);
        glVertex2f(0.30, 0.20);
        glVertex2f(0.30, 0.50);
        glVertex2f(0.15, 0.50);
    glEnd();

    // =====================================================
    //                  PIERNAS CHOCOLATE SUAVE
    // =====================================================

    glColor3f(0.6, 0.4, 0.2); // Chocolate suave

    // Pierna izquierda
    glBegin(GL_POLYGON);
        glVertex2f(-0.15, -0.30);
        glVertex2f(0.00, -0.30);
        glVertex2f(0.00, 0.10);
        glVertex2f(-0.15, 0.10);
    glEnd();

    // Pierna derecha
    glBegin(GL_POLYGON);
        glVertex2f(0.00, -0.30);
        glVertex2f(0.15, -0.30);
        glVertex2f(0.15, 0.10);
        glVertex2f(0.00, 0.10);
    glEnd();

    // Bordes piernas
    glColor3f(0.0, 0.0, 0.0);

    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.15, -0.30);
        glVertex2f(0.00, -0.30);
        glVertex2f(0.00, 0.10);
        glVertex2f(-0.15, 0.10);
    glEnd();

    glBegin(GL_LINE_LOOP);
        glVertex2f(0.00, -0.30);
        glVertex2f(0.15, -0.30);
        glVertex2f(0.15, 0.10);
        glVertex2f(0.00, 0.10);
    glEnd();

    // =====================================================
    //                  CARA ENOJADA
    // =====================================================

    glColor3f(0.0, 0.0, 0.0);

    // Cejas
    glBegin(GL_LINES);
        glVertex2f(-0.12, 0.78);
        glVertex2f(-0.04, 0.75);

        glVertex2f(0.04, 0.75);
        glVertex2f(0.12, 0.78);
    glEnd();

    // Ojos
    glBegin(GL_LINES);
        glVertex2f(-0.10, 0.70);
        glVertex2f(-0.04, 0.70);

        glVertex2f(0.04, 0.70);
        glVertex2f(0.10, 0.70);
    glEnd();

    // Boca
    glBegin(GL_LINES);
        glVertex2f(-0.06, 0.60);
        glVertex2f(0.06, 0.60);
    glEnd();

    // =====================================================
    //                  TEXTO
    // =====================================================

    texto(-0.10, -0.45, "ENOJADO");

    // =====================================================
    //                  ROMBO
    // =====================================================

    glBegin(GL_LINE_LOOP);
        glVertex2f(0.00, -0.55);
        glVertex2f(0.08, -0.65);
        glVertex2f(0.00, -0.75);
        glVertex2f(-0.08, -0.65);
    glEnd();

    glFlush();
}

void init()
{
    glClearColor(1.0, 1.0, 1.0, 1.0);

    glMatrixMode(GL_PROJECTION);

    gluOrtho2D(-1, 1, -1, 1);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);

    glutInitWindowSize(600, 600);

    glutCreateWindow("Muneco Enfado - OpenGL GLUT");

    init();

    glutDisplayFunc(display);

    glutMainLoop();

    return 0;
}
